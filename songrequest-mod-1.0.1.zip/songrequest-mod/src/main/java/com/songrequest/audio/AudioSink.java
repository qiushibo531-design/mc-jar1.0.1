package com.songrequest.audio;

/** PCM 輸出抽象（16-bit little-endian、交錯聲道）。 */
public interface AudioSink {
    void open(int sampleRate, int channels) throws Exception;

    void write(byte[] data, int off, int len);

    void pause();

    void resume();

    /** 已播放的微秒數（暫停時凍結）。 */
    long positionMicros();

    /** 等待緩衝播完後關閉。 */
    void drain();

    /** 立即中止並關閉。 */
    void abort();
}
