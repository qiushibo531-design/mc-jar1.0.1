package com.songrequest.audio;

import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.DoubleSupplier;

/**
 * 以 OpenAL 輸出（Minecraft 本來就在用 LWJGL OpenAL，手機啟動器也支援）。
 * 解碼執行緒只把 PCM 塞進佇列；所有 AL 呼叫都在客戶端主執行緒的 {@link #tickAll()} 內完成。
 */
public final class OpenAlSink implements AudioSink {

    private static final List<OpenAlSink> ACTIVE = new CopyOnWriteArrayList<>();
    private static volatile DoubleSupplier gainSupplier = () -> 1.0;

    private static final int AL_BUFFERS = 6;
    private static final double CHUNK_SECONDS = 0.2;

    public static void setGainSupplier(DoubleSupplier s) {
        gainSupplier = s;
    }

    /** 每個客戶端 tick 呼叫一次（主執行緒）。 */
    public static void tickAll() {
        for (OpenAlSink s : ACTIVE) {
            try {
                s.tick();
            } catch (Throwable t) {
                s.fail(t);
            }
        }
    }

    // ---- 跨執行緒狀態 ----
    private final ArrayBlockingQueue<byte[]> pending = new ArrayBlockingQueue<>(10); // ≈2 秒
    private final ByteArrayOutputStream staging = new ByteArrayOutputStream();
    private final CountDownLatch done = new CountDownLatch(1);
    private volatile boolean paused;
    private volatile boolean aborted;
    private volatile boolean finishedWriting;
    private volatile Throwable failure;
    private volatile long posMicrosAtTick;
    private volatile long tickNanos;
    private volatile boolean playingNow;

    private int rate, channels, alFormat, chunkBytes;

    // ---- 只在主執行緒使用 ----
    private int source;
    private final ArrayDeque<Integer> freeBuffers = new ArrayDeque<>();
    private final Map<Integer, Integer> bufferFrames = new HashMap<>();
    private int[] allBuffers;
    private int queuedInAl;
    private long playedFrames;

    @Override
    public void open(int sampleRate, int channels) {
        this.rate = sampleRate;
        this.channels = channels;
        this.alFormat = channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
        int frame = channels * 2;
        this.chunkBytes = (int) (sampleRate * CHUNK_SECONDS) * frame;
        this.tickNanos = System.nanoTime();
        ACTIVE.add(this);
    }

    // ---------------------------------------------------------------- 解碼執行緒

    @Override
    public void write(byte[] data, int off, int len) {
        staging.write(data, off, len);
        if (staging.size() >= chunkBytes) flushStaging();
    }

    private void flushStaging() {
        if (staging.size() == 0) return;
        byte[] chunk = staging.toByteArray();
        staging.reset();
        try {
            while (!aborted && failure == null) {
                if (pending.offer(chunk, 50, TimeUnit.MILLISECONDS)) return;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void pause() {
        paused = true;
    }

    @Override
    public void resume() {
        paused = false;
    }

    @Override
    public long positionMicros() {
        long base = posMicrosAtTick;
        if (playingNow && !paused) base += (System.nanoTime() - tickNanos) / 1000;
        return base;
    }

    @Override
    public void drain() {
        flushStaging();
        finishedWriting = true;
        try {
            done.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        throwIfFailed();
    }

    @Override
    public void abort() {
        aborted = true;
        pending.clear();
        // 資源由主執行緒的下一次 tick 釋放
    }

    private void throwIfFailed() {
        Throwable t = failure;
        if (t != null) throw new RuntimeException(t.getMessage() == null ? "OpenAL error" : "OpenAL: " + t.getMessage(), t);
    }

    private void fail(Throwable t) {
        failure = t;
        cleanup();
        done.countDown();
    }

    // ---------------------------------------------------------------- 主執行緒

    private void tick() throws IOException {
        if (aborted) {
            cleanup();
            done.countDown();
            return;
        }
        if (source == 0) createSource();

        // 回收已播完的緩衝
        int processed = AL10.alGetSourcei(source, AL10.AL_BUFFERS_PROCESSED);
        while (processed-- > 0) {
            int b = AL10.alSourceUnqueueBuffers(source);
            Integer frames = bufferFrames.remove(b);
            if (frames != null) playedFrames += frames;
            freeBuffers.add(b);
            queuedInAl--;
        }

        // 填入新的 PCM
        while (!freeBuffers.isEmpty()) {
            byte[] chunk = pending.poll();
            if (chunk == null) break;
            int b = freeBuffers.poll();
            ByteBuffer direct = BufferUtils.createByteBuffer(chunk.length);
            direct.put(chunk).flip();
            AL10.alBufferData(b, alFormat, direct, rate);
            AL10.alSourceQueueBuffers(source, b);
            bufferFrames.put(b, chunk.length / (channels * 2));
            queuedInAl++;
        }

        AL10.alSourcef(source, AL10.AL_GAIN, (float) Math.max(0, Math.min(1, gainSupplier.getAsDouble())));

        int state = AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE);
        if (paused) {
            if (state == AL10.AL_PLAYING) AL10.alSourcePause(source);
        } else if (state != AL10.AL_PLAYING && queuedInAl > 0) {
            AL10.alSourcePlay(source); // 首次播放，或緩衝見底後重新開始
        }

        long offset = (state == AL10.AL_PLAYING || state == AL10.AL_PAUSED)
                ? AL10.alGetSourcei(source, AL11.AL_SAMPLE_OFFSET) : 0;
        posMicrosAtTick = (playedFrames + offset) * 1_000_000L / rate;
        tickNanos = System.nanoTime();
        playingNow = state == AL10.AL_PLAYING;

        if (finishedWriting && pending.isEmpty() && queuedInAl == 0) {
            cleanup();
            done.countDown();
        }
    }

    private void createSource() throws IOException {
        AL10.alGetError(); // 清掉先前的錯誤
        source = AL10.alGenSources();
        if (AL10.alGetError() != AL10.AL_NO_ERROR || source == 0) {
            source = 0;
            throw new IOException("alGenSources failed");
        }
        AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE); // 不做 3D 定位，聲音永遠在耳邊
        AL10.alSource3f(source, AL10.AL_POSITION, 0f, 0f, 0f);
        allBuffers = new int[AL_BUFFERS];
        for (int i = 0; i < AL_BUFFERS; i++) {
            allBuffers[i] = AL10.alGenBuffers();
            freeBuffers.add(allBuffers[i]);
        }
    }

    private void cleanup() {
        ACTIVE.remove(this);
        try {
            if (source != 0) {
                AL10.alSourceStop(source);
                int n = AL10.alGetSourcei(source, AL10.AL_BUFFERS_QUEUED);
                while (n-- > 0) AL10.alSourceUnqueueBuffers(source);
                AL10.alDeleteSources(source);
                source = 0;
            }
            if (allBuffers != null) {
                for (int b : allBuffers) AL10.alDeleteBuffers(b);
                allBuffers = null;
            }
        } catch (Throwable ignored) {
            // 關閉遊戲或音效引擎重載時可能已無有效 context
        }
        playingNow = false;
    }
}
