package com.songrequest.audio;

import com.songrequest.api.Lyrics;
import com.songrequest.api.Song;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;

/**
 * 播放佇列 + 解碼播放。與 Minecraft 無關，方便獨立測試。
 * 一次只有一個 Worker 執行緒在解碼；切歌時舊 Worker 會被取消。
 */
public final class MusicPlayer {

    public interface AudioOpener {
        InputStream open(Song song) throws Exception;
    }

    public interface LyricsLoader {
        Lyrics load(Song song) throws Exception;
    }

    private final Object lock = new Object();
    private final LinkedList<Song> queue = new LinkedList<>();
    private final Supplier<AudioSink> sinkFactory;
    private final AudioOpener opener;
    private final LyricsLoader lyricsLoader;

    private volatile DoubleSupplier volume = () -> 1.0;
    private volatile Consumer<String> errorHandler = s -> {};

    private volatile Song current;
    private volatile Lyrics lyrics = Lyrics.EMPTY;
    private volatile boolean paused;
    private volatile boolean loading;
    private volatile Worker worker;

    public MusicPlayer(Supplier<AudioSink> sinkFactory, AudioOpener opener, LyricsLoader lyricsLoader) {
        this.sinkFactory = sinkFactory;
        this.opener = opener;
        this.lyricsLoader = lyricsLoader;
    }

    public void setVolumeSupplier(DoubleSupplier supplier) {
        this.volume = supplier;
    }

    /** 錯誤回呼，參數為錯誤代碼（"no_audio" 或例外訊息）加上歌名，於背景執行緒呼叫。 */
    public void setErrorHandler(Consumer<String> handler) {
        this.errorHandler = handler;
    }

    // ---------- 狀態查詢 ----------

    public Song current() { return current; }
    public Lyrics lyrics() { return lyrics; }
    public boolean isPaused() { return paused; }
    public boolean isLoading() { return loading; }

    public long positionMs() {
        Worker w = worker;
        if (w == null || w.sink == null || !w.started) return 0;
        return w.sink.positionMicros() / 1000;
    }

    public List<Song> queueSnapshot() {
        synchronized (lock) {
            return new ArrayList<>(queue);
        }
    }

    // ---------- 控制 ----------

    /** 立即播放（不影響佇列）。 */
    public void playNow(Song song) {
        synchronized (lock) {
            startLocked(song);
        }
    }

    /** 加入佇列；沒有歌在播時直接開始。 */
    public void enqueue(Song song) {
        synchronized (lock) {
            if (current == null) startLocked(song);
            else queue.add(song);
        }
    }

    public void playFromQueue(int index) {
        synchronized (lock) {
            if (index < 0 || index >= queue.size()) return;
            startLocked(queue.remove(index));
        }
    }

    public void removeFromQueue(int index) {
        synchronized (lock) {
            if (index >= 0 && index < queue.size()) queue.remove(index);
        }
    }

    public void skip() {
        synchronized (lock) {
            advanceLocked();
        }
    }

    public void stop() {
        synchronized (lock) {
            queue.clear();
            stopLocked();
        }
    }

    public void togglePause() {
        synchronized (lock) {
            Worker w = worker;
            if (current == null || w == null) return;
            paused = !paused;
            if (w.sink != null && w.started) {
                if (paused) w.sink.pause();
                else w.sink.resume();
            }
        }
    }

    // ---------- 內部 ----------

    private void startLocked(Song song) {
        cancelWorkerLocked();
        current = song;
        lyrics = Lyrics.EMPTY;
        paused = false;
        loading = true;
        Worker w = new Worker(song);
        worker = w;
        Thread t = new Thread(w, "SongRequest-Player");
        t.setDaemon(true);
        w.thread = t;
        t.start();
        Thread lt = new Thread(() -> {
            try {
                Lyrics l = lyricsLoader.load(song);
                if (!w.cancelled) lyrics = l;
            } catch (Exception ignored) {
                // 沒有歌詞不影響播放
            }
        }, "SongRequest-Lyrics");
        lt.setDaemon(true);
        lt.start();
    }

    private void advanceLocked() {
        Song next = queue.poll();
        if (next != null) startLocked(next);
        else stopLocked();
    }

    private void stopLocked() {
        cancelWorkerLocked();
        current = null;
        lyrics = Lyrics.EMPTY;
        paused = false;
        loading = false;
        worker = null;
    }

    private void cancelWorkerLocked() {
        Worker w = worker;
        if (w != null) w.cancel();
    }

    /** Worker 自然播完或出錯時呼叫；只有仍是目前 Worker 才會切到下一首。 */
    private void onWorkerDone(Worker w) {
        synchronized (lock) {
            if (worker == w && !w.cancelled) advanceLocked();
        }
    }

    private final class Worker implements Runnable {
        final Song song;
        volatile boolean cancelled;
        volatile boolean started;
        volatile AudioSink sink;
        volatile Thread thread;
        private volatile InputStream stream;

        Worker(Song song) {
            this.song = song;
        }

        void cancel() {
            cancelled = true;
            Thread t = thread;
            if (t != null) t.interrupt();
            AudioSink s = sink;
            if (s != null) s.abort();
            InputStream in = stream;
            if (in != null) {
                try { in.close(); } catch (Exception ignored) {}
            }
        }

        @Override
        public void run() {
            try {
                InputStream raw = opener.open(song);
                if (cancelled) {
                    raw.close();
                    return;
                }
                stream = raw;
                try (InputStream in = new BufferedInputStream(raw, 1 << 16)) {
                    decodeLoop(in);
                }
            } catch (Throwable t) {
                if (!cancelled) {
                    String msg = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
                    errorHandler.accept(msg + "\u0000" + song.name());
                }
            } finally {
                if (!cancelled) {
                    loading = false;
                    onWorkerDone(this);
                }
            }
        }

        private void decodeLoop(InputStream in) throws Exception {
            Bitstream bs = new Bitstream(in);
            Decoder dec = new Decoder();
            byte[] out = new byte[0];
            boolean natural = false;
            while (!cancelled) {
                Header h = bs.readFrame();
                if (h == null) {
                    natural = true;
                    break;
                }
                SampleBuffer pcm = (SampleBuffer) dec.decodeFrame(h, bs);
                if (sink == null) {
                    AudioSink s = sinkFactory.get();
                    s.open(dec.getOutputFrequency(), dec.getOutputChannels());
                    sink = s;
                    started = true;
                    loading = false;
                    if (cancelled) { s.abort(); return; }
                    if (paused) s.pause();
                }
                short[] samples = pcm.getBuffer();
                int n = pcm.getBufferLength();
                if (out.length < n * 2) out = new byte[n * 2];
                double v = Math.max(0, Math.min(1, volume.getAsDouble()));
                for (int i = 0; i < n; i++) {
                    int s = (int) Math.round(samples[i] * v);
                    out[2 * i] = (byte) s;
                    out[2 * i + 1] = (byte) (s >> 8);
                }
                while (paused && !cancelled) Thread.sleep(30);
                if (cancelled) break;
                sink.write(out, 0, n * 2);
                bs.closeFrame();
            }
            AudioSink s = sink;
            if (s != null) {
                if (natural && !cancelled) s.drain();
                else s.abort();
            }
        }
    }
}
