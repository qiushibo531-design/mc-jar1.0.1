package com.songrequest.api;

import com.songrequest.Config;

import java.util.List;

public final class Providers {
    public static final List<MusicProvider> ALL = List.of(new NeteaseProvider(), new QQMusicProvider());

    private Providers() {}

    public static MusicProvider byId(String id) {
        for (MusicProvider p : ALL) if (p.id().equals(id)) return p;
        return ALL.get(0);
    }

    public static MusicProvider selected() {
        return byId(Config.get().source);
    }

    /** 切換到下一個音源並回傳。 */
    public static MusicProvider cycle() {
        int i = ALL.indexOf(selected());
        MusicProvider next = ALL.get((i + 1) % ALL.size());
        Config.get().source = next.id();
        return next;
    }
}
