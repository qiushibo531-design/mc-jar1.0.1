package com.songrequest.api;

/**
 * 一首歌曲。source 為音源代號（netease / qq），id 為該音源內的歌曲 ID，
 * extra 放音源專屬的附加資料（例如 QQ 音樂的 media_mid）。
 */
public record Song(String source, String id, String name, String artist, String album,
                   long durationMs, String extra) {

    public String key() {
        return source + ":" + id;
    }

    public String durationText() {
        long s = Math.max(0, durationMs / 1000);
        return String.format("%d:%02d", s / 60, s % 60);
    }
}
