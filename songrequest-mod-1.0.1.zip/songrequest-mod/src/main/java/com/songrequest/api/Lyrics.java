package com.songrequest.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** LRC 歌詞解析，支援同行多個時間戳與翻譯歌詞（tlyric）。 */
public final class Lyrics {

    public record Line(long timeMs, String text, String translation) {}

    public static final Lyrics EMPTY = new Lyrics(List.of());

    private static final Pattern STAMP = Pattern.compile("\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?]");

    private final List<Line> lines;

    private Lyrics(List<Line> lines) {
        this.lines = lines;
    }

    public boolean isEmpty() {
        return lines.isEmpty();
    }

    public int size() {
        return lines.size();
    }

    public Line get(int index) {
        return index >= 0 && index < lines.size() ? lines.get(index) : null;
    }

    /** 回傳播放到 positionMs 時應顯示的行號；尚未開始回傳 -1。 */
    public int indexAt(long positionMs) {
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).timeMs() <= positionMs) {
                ans = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return ans;
    }

    public static Lyrics parse(String lrc, String translationLrc) {
        if (lrc == null || lrc.isBlank()) return EMPTY;
        Map<Long, String> trans = new HashMap<>();
        for (Entry e : parseEntries(translationLrc)) trans.put(e.time, e.text);

        List<Line> out = new ArrayList<>();
        for (Entry e : parseEntries(lrc)) {
            out.add(new Line(e.time, e.text, trans.get(e.time)));
        }
        out.sort((a, b) -> Long.compare(a.timeMs(), b.timeMs()));
        return out.isEmpty() ? EMPTY : new Lyrics(List.copyOf(out));
    }

    private record Entry(long time, String text) {}

    private static List<Entry> parseEntries(String lrc) {
        List<Entry> result = new ArrayList<>();
        if (lrc == null) return result;
        for (String raw : lrc.split("\\r?\\n")) {
            Matcher m = STAMP.matcher(raw);
            List<Long> times = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                long min = Long.parseLong(m.group(1));
                long sec = Long.parseLong(m.group(2));
                long ms = 0;
                String frac = m.group(3);
                if (frac != null) {
                    ms = Long.parseLong(frac);
                    if (frac.length() == 1) ms *= 100;
                    else if (frac.length() == 2) ms *= 10;
                }
                times.add(min * 60_000 + sec * 1000 + ms);
                end = m.end();
            }
            if (times.isEmpty()) continue; // 中繼資料行 [ar:xxx] 等直接忽略
            String text = raw.substring(end).trim();
            for (long t : times) result.add(new Entry(t, text));
        }
        return result;
    }
}
