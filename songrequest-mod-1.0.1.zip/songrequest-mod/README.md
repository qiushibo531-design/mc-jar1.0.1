# SongRequest 点歌台（Fabric 1.20.4）
作者：狮子叔叔Uncle Lion　授权：MIT

圖形介面點歌台，參考 SimpMusic 重寫：

- **按 `M` 開啟點歌台**：搜尋 → 點歌名立即播放 / 點右側 `+` 加入佇列。完全不用輸入指令。
- **字幕在螢幕正上方**：歌名 - 歌手、當前歌詞（大字）、翻譯或下一句（小字）。不再使用 Minecraft 右下角的聲音字幕。
- 播放佇列、暫停/繼續、下一首、停止、音量滑桿；無版權/VIP 歌曲會自動跳過。
- 快捷鍵（可在「按鍵控制」改）：`M` 開啟、下一首、暫停（後兩者預設未綁定）。
- 設定檔 `config/songrequest.json`：`hudY`（字幕距頂部）、`hudScale`、`showTranslation`、`hudBackground`、`lyricOffsetMs`（歌詞快慢微調）。

## 建置
```
./gradlew build        # 產物在 build/libs/songrequest-1.0.0.jar
./gradlew runClient    # 開發環境測試
```
需要 JDK 17+。依賴：Fabric Loader ≥0.15、Fabric API 0.97.3+1.20.4。MP3 解碼庫 jlayer 已用 Jar-in-Jar 內嵌。

## 結構
- `api/` 網易雲搜尋、歌詞（LRC＋翻譯）、音源
- `audio/` 佇列與解碼播放（與 Minecraft 無關），以 javax.sound 輸出
- `gui/MusicScreen` 點歌介面　`hud/LyricsHud` 頂部字幕

## 音源
介面右上角「音源」按鈕可切換：网易云音乐、QQ音乐（實驗性）。
無法播放時（VIP／無版權／需登入）會在動作列顯示原因代碼，完整資訊在 `logs/latest.log` 搜尋 `SongRequest`。
需要登入才能播的歌，把 Cookie 填入 `config/songrequest.json` 的 `neteaseCookie`（例如 `MUSIC_U=...`）或 `qqCookie`（例如 `uin=...; qqmusic_key=...`）。
新增音源：實作 `api/MusicProvider` 並加進 `api/Providers.ALL`。
